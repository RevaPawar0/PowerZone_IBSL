/**
 * POWERZONE : GYM & SPORTS STORE
 * Official Sports Gear, Cricket, Football & Gym Equipment Catalog Data
 */

const POWERZONE_PRODUCTS = [
  {
    id: 'pz-1',
    name: 'Pro Turf Studs / Football Shoes (Multi-Ground)',
    category: 'football',
    price: 2499,
    oldPrice: 3200,
    rating: 4.9,
    reviews: 164,
    badge: 'Best Seller',
    image: 'https://images.unsplash.com/photo-1511556532299-8f662fc26c06?w=600&auto=format&fit=crop&q=80',
    desc: 'High-traction TPU molded studs for artificial turf & grass grounds. Reinforced heel counter and breathable mesh upper for explosive speed.'
  },
  {
    id: 'pz-2',
    name: 'Grade 1 Kashmir Willow Cricket Bat (Full Size)',
    category: 'cricket',
    price: 2899,
    oldPrice: 3800,
    rating: 5.0,
    reviews: 198,
    badge: 'Pro Choice',
    image: 'https://images.unsplash.com/photo-1531415074968-036ba1b575da?w=600&auto=format&fit=crop&q=80',
    desc: 'Handcrafted premium Kashmir Willow with 38-40mm massive edges, thick sweet spot, cane handle with chevron rubber grip for powerful boundary hitting.'
  },
  {
    id: 'pz-3',
    name: 'Custom Tournament Brass/Gold Trophy & Medals Set',
    category: 'trophies',
    price: 3999,
    oldPrice: 4999,
    rating: 4.9,
    reviews: 82,
    badge: 'Club Special',
    image: 'https://images.unsplash.com/photo-1579952363873-27f3bade9f55?w=600&auto=format&fit=crop&q=80',
    desc: 'Customizable championship gold cup trophy (18-inch) + 20 tournament brass medals with ribbon neckbands for local sports tournaments & leagues.'
  },
  {
    id: 'pz-4',
    name: '10mm Heavy Duty Leather Powerlifting Lever Belt',
    category: 'gym',
    price: 2199,
    oldPrice: 2899,
    rating: 4.9,
    reviews: 210,
    badge: 'IPF Spec',
    image: 'https://images.unsplash.com/photo-1517963879433-6ad2b056d712?w=600&auto=format&fit=crop&q=80',
    desc: 'Top-grain 10mm non-slip suede leather with zinc-alloy chrome quick-release lever. Uncompromising intra-abdominal support for heavy squats & deadlifts.'
  },
  {
    id: 'pz-5',
    name: 'Pro Carbon Graphite Badminton Rackets Set (Pack of 2)',
    category: 'badminton',
    price: 1899,
    oldPrice: 2499,
    rating: 4.8,
    reviews: 145,
    badge: 'High Tension',
    image: 'https://images.unsplash.com/photo-1626224583764-f87db24ac4ea?w=600&auto=format&fit=crop&q=80',
    desc: 'Isometric high-modulus graphite frame pre-strung at 28 lbs tension with full padded carry bag and 3 nylon shuttles included.'
  },
  {
    id: 'pz-6',
    name: 'Latex Resistance Loop Bands (Set of 5 Levels)',
    category: 'accessories',
    price: 799,
    oldPrice: 1199,
    rating: 4.9,
    reviews: 320,
    badge: 'Essential',
    image: 'https://images.unsplash.com/photo-1598289431512-b97b0917affc?w=600&auto=format&fit=crop&q=80',
    desc: '100% natural Malaysian latex bands (Extra Light to Extra Heavy) with door anchor, workout guide booklet, and compact travel pouch.'
  },
  {
    id: 'pz-7',
    name: 'Commercial Hex Rubber Dumbbells Pair (15kg x 2)',
    category: 'gym',
    price: 3499,
    oldPrice: 4400,
    rating: 4.9,
    reviews: 115,
    badge: 'Heavy Iron',
    image: 'https://images.unsplash.com/photo-1638803040283-7a5ffd48dad5?w=600&auto=format&fit=crop&q=80',
    desc: 'Solid cast iron core encased in heavy-duty anti-crack rubber with knurled ergonomic chrome grip. Zero floor damage and minimal bounce.'
  },
  {
    id: 'pz-8',
    name: 'Match Quality Synthetic Leather Volleyball & Net Kit',
    category: 'football',
    price: 1299,
    oldPrice: 1799,
    rating: 4.8,
    reviews: 94,
    badge: 'Official Size',
    image: 'https://images.unsplash.com/photo-1612872087720-bb876e2e67d1?w=600&auto=format&fit=crop&q=80',
    desc: 'Soft-touch PU composite leather 18-panel volleyball with official size braided nylon net and inflating hand pump with needle.'
  }
];
